#include "src/Menu.h"

int main() {
    Menu menu = Menu();
    return 0;
}
